from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Dict, Any, List
import json
import re
from datetime import datetime

class FinancialDataFormatterInput(BaseModel):
    """Input schema for Financial Data Formatter Tool."""
    financial_text: str = Field(..., description="Raw financial analysis text or data to be formatted")

class FinancialDataFormatterTool(BaseTool):
    """Tool for formatting raw financial analysis text into structured formats."""

    name: str = "financial_data_formatter"
    description: str = (
        "Formats raw financial analysis text into structured formats including JSON, CSV, "
        "SQL schema documentation, validation reports, and markdown templates. "
        "Takes financial text as input and returns a dictionary with formatted outputs."
    )
    args_schema: Type[BaseModel] = FinancialDataFormatterInput

    def _run(self, financial_text: str) -> str:
        """
        Format financial data into multiple structured formats.
        
        Args:
            financial_text: Raw financial analysis text or data
            
        Returns:
            JSON string containing formatted data in multiple formats
        """
        try:
            # Extract financial metrics from text
            extracted_data = self._extract_financial_metrics(financial_text)
            
            # Generate structured formats
            json_data = self._generate_json_format(extracted_data)
            csv_data = self._generate_csv_format(extracted_data)
            sql_schema = self._generate_sql_schema(extracted_data)
            validation_report = self._validate_data_quality(extracted_data)
            markdown_template = self._generate_markdown_template(extracted_data)
            
            result = {
                'json_data': json_data,
                'csv_data': csv_data,
                'sql_schema': sql_schema,
                'validation_report': validation_report,
                'markdown_template': markdown_template
            }
            
            return json.dumps(result, indent=2)
            
        except Exception as e:
            return json.dumps({
                'error': f'Failed to format financial data: {str(e)}',
                'json_data': {},
                'csv_data': '',
                'sql_schema': '',
                'validation_report': {'status': 'error', 'message': str(e)},
                'markdown_template': ''
            }, indent=2)

    def _extract_financial_metrics(self, text: str) -> Dict[str, Any]:
        """Extract financial metrics from raw text."""
        data = {
            'company_info': {},
            'financial_metrics': {},
            'risk_assessment': {},
            'esg_scores': {},
            'compliance_data': {},
            'peer_comparisons': {}
        }
        
        # Extract company information
        company_match = re.search(r'(?:company|corporation|corp)[:\s]+([A-Za-z\s&\.]+)', text, re.IGNORECASE)
        if company_match:
            data['company_info']['name'] = company_match.group(1).strip()
        
        # Extract financial metrics using regex patterns
        revenue_match = re.search(r'revenue[:\s]+\$?([0-9,\.]+)([MBK]?)', text, re.IGNORECASE)
        if revenue_match:
            amount = float(revenue_match.group(1).replace(',', ''))
            multiplier = {'M': 1000000, 'B': 1000000000, 'K': 1000}.get(revenue_match.group(2), 1)
            data['financial_metrics']['revenue'] = amount * multiplier
        
        profit_match = re.search(r'(?:profit|net income)[:\s]+\$?([0-9,\.]+)([MBK]?)', text, re.IGNORECASE)
        if profit_match:
            amount = float(profit_match.group(1).replace(',', ''))
            multiplier = {'M': 1000000, 'B': 1000000000, 'K': 1000}.get(profit_match.group(2), 1)
            data['financial_metrics']['net_income'] = amount * multiplier
        
        # Extract ratios
        pe_match = re.search(r'(?:P/E|PE ratio)[:\s]+([0-9\.]+)', text, re.IGNORECASE)
        if pe_match:
            data['financial_metrics']['pe_ratio'] = float(pe_match.group(1))
        
        debt_match = re.search(r'debt[:\s]+\$?([0-9,\.]+)([MBK]?)', text, re.IGNORECASE)
        if debt_match:
            amount = float(debt_match.group(1).replace(',', ''))
            multiplier = {'M': 1000000, 'B': 1000000000, 'K': 1000}.get(debt_match.group(2), 1)
            data['financial_metrics']['total_debt'] = amount * multiplier
        
        # Extract ESG scores
        esg_matches = re.findall(r'(?:ESG|environmental|social|governance)[:\s]+([0-9\.]+)', text, re.IGNORECASE)
        if esg_matches:
            data['esg_scores']['overall_score'] = float(esg_matches[0])
        
        # Extract risk ratings
        risk_match = re.search(r'risk rating[:\s]+([A-Za-z\+\-]+)', text, re.IGNORECASE)
        if risk_match:
            data['risk_assessment']['rating'] = risk_match.group(1).upper()
        
        return data

    def _generate_json_format(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate structured JSON format."""
        return {
            'timestamp': datetime.now().isoformat(),
            'data_version': '1.0',
            'company_info': {
                'name': data['company_info'].get('name', 'N/A'),
                'sector': data['company_info'].get('sector', 'N/A'),
                'market_cap': data['company_info'].get('market_cap', None)
            },
            'financial_metrics': {
                'revenue': data['financial_metrics'].get('revenue', None),
                'net_income': data['financial_metrics'].get('net_income', None),
                'pe_ratio': data['financial_metrics'].get('pe_ratio', None),
                'total_debt': data['financial_metrics'].get('total_debt', None),
                'debt_to_equity': data['financial_metrics'].get('debt_to_equity', None),
                'roe': data['financial_metrics'].get('roe', None),
                'roa': data['financial_metrics'].get('roa', None)
            },
            'risk_assessment': {
                'overall_rating': data['risk_assessment'].get('rating', 'N/A'),
                'credit_risk': data['risk_assessment'].get('credit_risk', None),
                'market_risk': data['risk_assessment'].get('market_risk', None),
                'operational_risk': data['risk_assessment'].get('operational_risk', None)
            },
            'esg_scores': {
                'overall_score': data['esg_scores'].get('overall_score', None),
                'environmental': data['esg_scores'].get('environmental', None),
                'social': data['esg_scores'].get('social', None),
                'governance': data['esg_scores'].get('governance', None)
            },
            'compliance_data': {
                'regulatory_status': data['compliance_data'].get('status', 'N/A'),
                'last_audit_date': data['compliance_data'].get('last_audit', None),
                'compliance_score': data['compliance_data'].get('score', None)
            },
            'peer_comparisons': data['peer_comparisons']
        }

    def _generate_csv_format(self, data: Dict[str, Any]) -> str:
        """Generate CSV-formatted string with headers."""
        csv_lines = []
        
        # Financial metrics CSV
        csv_lines.append("# Financial Metrics")
        csv_lines.append("Metric,Value,Unit,Data_Type")
        
        metrics = data['financial_metrics']
        for key, value in metrics.items():
            if value is not None:
                unit = 'USD' if 'revenue' in key or 'income' in key or 'debt' in key else 'ratio'
                data_type = 'float' if isinstance(value, (int, float)) else 'string'
                csv_lines.append(f"{key},{value},{unit},{data_type}")
        
        csv_lines.append("")
        csv_lines.append("# ESG Scores")
        csv_lines.append("Category,Score,Max_Score,Data_Type")
        
        esg = data['esg_scores']
        for key, value in esg.items():
            if value is not None:
                csv_lines.append(f"{key},{value},100,float")
        
        return "\n".join(csv_lines)

    def _generate_sql_schema(self, data: Dict[str, Any]) -> str:
        """Generate SQL DDL statements as documentation text."""
        schema = []
        
        # Company information table
        schema.append("-- Financial Data Schema Documentation")
        schema.append("-- Table: company_info")
        schema.append("""
CREATE TABLE company_info (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    sector VARCHAR(100),
    market_cap DECIMAL(15,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);""")
        
        # Financial metrics table
        schema.append("\n-- Table: financial_metrics")
        schema.append("""
CREATE TABLE financial_metrics (
    id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES company_info(id),
    report_date DATE NOT NULL,
    revenue DECIMAL(15,2),
    net_income DECIMAL(15,2),
    pe_ratio DECIMAL(8,2),
    total_debt DECIMAL(15,2),
    debt_to_equity DECIMAL(8,4),
    roe DECIMAL(8,4),
    roa DECIMAL(8,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);""")
        
        # ESG scores table
        schema.append("\n-- Table: esg_scores")
        schema.append("""
CREATE TABLE esg_scores (
    id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES company_info(id),
    assessment_date DATE NOT NULL,
    overall_score DECIMAL(5,2),
    environmental_score DECIMAL(5,2),
    social_score DECIMAL(5,2),
    governance_score DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);""")
        
        # Risk assessment table
        schema.append("\n-- Table: risk_assessment")
        schema.append("""
CREATE TABLE risk_assessment (
    id SERIAL PRIMARY KEY,
    company_id INTEGER REFERENCES company_info(id),
    assessment_date DATE NOT NULL,
    overall_rating VARCHAR(10),
    credit_risk VARCHAR(10),
    market_risk VARCHAR(10),
    operational_risk VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);""")
        
        return "\n".join(schema)

    def _validate_data_quality(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate data integrity and completeness."""
        validation_report = {
            'status': 'passed',
            'overall_score': 0,
            'checks': {},
            'warnings': [],
            'errors': []
        }
        
        total_checks = 0
        passed_checks = 0
        
        # Check company info completeness
        total_checks += 1
        if data['company_info'].get('name'):
            passed_checks += 1
            validation_report['checks']['company_name'] = 'passed'
        else:
            validation_report['checks']['company_name'] = 'failed'
            validation_report['warnings'].append('Company name not found in input text')
        
        # Check financial metrics presence
        financial_metrics = data['financial_metrics']
        metrics_count = sum(1 for v in financial_metrics.values() if v is not None)
        total_checks += 1
        
        if metrics_count >= 2:
            passed_checks += 1
            validation_report['checks']['financial_metrics'] = 'passed'
        else:
            validation_report['checks']['financial_metrics'] = 'failed'
            validation_report['warnings'].append(f'Only {metrics_count} financial metrics found')
        
        # Validate data ranges
        if financial_metrics.get('pe_ratio'):
            total_checks += 1
            pe_ratio = financial_metrics['pe_ratio']
            if 0 < pe_ratio < 100:
                passed_checks += 1
                validation_report['checks']['pe_ratio_range'] = 'passed'
            else:
                validation_report['checks']['pe_ratio_range'] = 'warning'
                validation_report['warnings'].append(f'PE ratio {pe_ratio} seems unusual')
        
        # Check ESG scores validity
        if data['esg_scores'].get('overall_score'):
            total_checks += 1
            esg_score = data['esg_scores']['overall_score']
            if 0 <= esg_score <= 100:
                passed_checks += 1
                validation_report['checks']['esg_score_range'] = 'passed'
            else:
                validation_report['checks']['esg_score_range'] = 'failed'
                validation_report['errors'].append(f'ESG score {esg_score} outside valid range (0-100)')
        
        # Calculate overall score
        if total_checks > 0:
            validation_report['overall_score'] = round((passed_checks / total_checks) * 100, 2)
        
        # Determine overall status
        if validation_report['errors']:
            validation_report['status'] = 'failed'
        elif validation_report['warnings']:
            validation_report['status'] = 'warning'
        else:
            validation_report['status'] = 'passed'
        
        validation_report['summary'] = f'{passed_checks}/{total_checks} checks passed'
        
        return validation_report

    def _generate_markdown_template(self, data: Dict[str, Any]) -> str:
        """Generate formatted markdown executive summary."""
        company_name = data['company_info'].get('name', 'Company Name')
        
        template = f"""# Financial Analysis Executive Summary

## Company Overview
**Company:** {company_name}  
**Analysis Date:** {datetime.now().strftime('%Y-%m-%d')}  
**Data Version:** 1.0

## Key Financial Metrics

| Metric | Value | Unit |
|--------|--------|------|"""
        
        # Add financial metrics to table
        metrics = data['financial_metrics']
        for key, value in metrics.items():
            if value is not None:
                formatted_key = key.replace('_', ' ').title()
                if isinstance(value, (int, float)) and value > 1000000:
                    formatted_value = f"${value:,.0f}"
                    unit = "USD"
                elif isinstance(value, (int, float)):
                    formatted_value = f"{value:.2f}"
                    unit = "ratio" if 'ratio' in key else "USD"
                else:
                    formatted_value = str(value)
                    unit = "-"
                template += f"\n| {formatted_key} | {formatted_value} | {unit} |"
        
        # Add ESG section if available
        if any(data['esg_scores'].values()):
            template += "\n\n## ESG Assessment\n"
            esg = data['esg_scores']
            if esg.get('overall_score'):
                template += f"**Overall ESG Score:** {esg['overall_score']}/100\n"
        
        # Add risk assessment if available
        if data['risk_assessment'].get('rating'):
            template += f"\n## Risk Assessment\n"
            template += f"**Overall Rating:** {data['risk_assessment']['rating']}\n"
        
        template += "\n## Data Quality\n"
        template += "- Data extraction completed successfully\n"
        template += "- Validation checks performed\n"
        template += "- Multiple output formats generated\n"
        
        template += "\n---\n*Generated by Financial Data Formatter Tool*"
        
        return template