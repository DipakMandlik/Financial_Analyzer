import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	FileReadTool,
	SerperDevTool
)
from enterprise_financial_analysis_intelligence_platform.tools.financial_data_formatter import FinancialDataFormatterTool





@CrewBase
class EnterpriseFinancialAnalysisIntelligencePlatformCrew:
    """EnterpriseFinancialAnalysisIntelligencePlatform crew"""

    
    @agent
    def financial_document_analyst(self) -> Agent:

        
        return Agent(
            config=self.agents_config["financial_document_analyst"],
            
            
            tools=[
				FileReadTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def investment_research_specialist(self) -> Agent:

        
        return Agent(
            config=self.agents_config["investment_research_specialist"],
            
            
            tools=[
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def risk_assessment_expert(self) -> Agent:

        
        return Agent(
            config=self.agents_config["risk_assessment_expert"],
            
            
            tools=[
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def esg_sustainability_analyst(self) -> Agent:

        
        return Agent(
            config=self.agents_config["esg_sustainability_analyst"],
            
            
            tools=[
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def comparative_financial_analyst(self) -> Agent:

        
        return Agent(
            config=self.agents_config["comparative_financial_analyst"],
            
            
            tools=[
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def financial_report_generator(self) -> Agent:

        
        return Agent(
            config=self.agents_config["financial_report_generator"],
            
            
            tools=[
				FileReadTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def regulatory_compliance_specialist(self) -> Agent:

        
        return Agent(
            config=self.agents_config["regulatory_compliance_specialist"],
            
            
            tools=[
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def data_export_documentation_specialist(self) -> Agent:

        
        return Agent(
            config=self.agents_config["data_export_documentation_specialist"],
            
            
            tools=[
				FileReadTool(),
				FinancialDataFormatterTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def quality_control_validation_specialist(self) -> Agent:

        
        return Agent(
            config=self.agents_config["quality_control_validation_specialist"],
            
            
            tools=[
				FileReadTool(),
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def error_handling_recovery_specialist(self) -> Agent:

        
        return Agent(
            config=self.agents_config["error_handling_recovery_specialist"],
            
            
            tools=[
				FileReadTool(),
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def data_persistence_integration_manager(self) -> Agent:

        
        return Agent(
            config=self.agents_config["data_persistence_integration_manager"],
            
            
            tools=[
				FileReadTool(),
				FinancialDataFormatterTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def process_monitoring_performance_analyst(self) -> Agent:

        
        return Agent(
            config=self.agents_config["process_monitoring_performance_analyst"],
            
            
            tools=[
				FileReadTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def executive_summary_decision_support_specialist(self) -> Agent:

        
        return Agent(
            config=self.agents_config["executive_summary_decision_support_specialist"],
            
            
            tools=[
				FileReadTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def analyze_financial_document(self) -> Task:
        return Task(
            config=self.tasks_config["analyze_financial_document"],
            markdown=False,
            
        )
    
    @task
    def conduct_market_research(self) -> Task:
        return Task(
            config=self.tasks_config["conduct_market_research"],
            markdown=False,
            
        )
    
    @task
    def perform_risk_assessment(self) -> Task:
        return Task(
            config=self.tasks_config["perform_risk_assessment"],
            markdown=False,
            
        )
    
    @task
    def esg_sustainability_analysis(self) -> Task:
        return Task(
            config=self.tasks_config["esg_sustainability_analysis"],
            markdown=False,
            
        )
    
    @task
    def peer_comparison_analysis(self) -> Task:
        return Task(
            config=self.tasks_config["peer_comparison_analysis"],
            markdown=False,
            
        )
    
    @task
    def regulatory_compliance_assessment(self) -> Task:
        return Task(
            config=self.tasks_config["regulatory_compliance_assessment"],
            markdown=False,
            
        )
    
    @task
    def generate_comprehensive_financial_report(self) -> Task:
        return Task(
            config=self.tasks_config["generate_comprehensive_financial_report"],
            markdown=False,
            
        )
    
    @task
    def extract_structure_financial_data(self) -> Task:
        return Task(
            config=self.tasks_config["extract_structure_financial_data"],
            markdown=False,
            
        )
    
    @task
    def quality_validation_cross_reference_check(self) -> Task:
        return Task(
            config=self.tasks_config["quality_validation_cross_reference_check"],
            markdown=False,
            
        )
    
    @task
    def error_detection_recovery_protocol(self) -> Task:
        return Task(
            config=self.tasks_config["error_detection_recovery_protocol"],
            markdown=False,
            
        )
    
    @task
    def data_persistence_api_integration_preparation(self) -> Task:
        return Task(
            config=self.tasks_config["data_persistence_api_integration_preparation"],
            markdown=False,
            
        )
    
    @task
    def performance_monitoring_process_optimization(self) -> Task:
        return Task(
            config=self.tasks_config["performance_monitoring_process_optimization"],
            markdown=False,
            
        )
    
    @task
    def executive_decision_support_summary(self) -> Task:
        return Task(
            config=self.tasks_config["executive_decision_support_summary"],
            markdown=False,
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the EnterpriseFinancialAnalysisIntelligencePlatform crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )

    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)
