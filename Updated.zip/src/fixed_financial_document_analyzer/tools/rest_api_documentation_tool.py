from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Dict, Any, List
import json

class RestAPIDocumentationToolInput(BaseModel):
    """Input schema for RestAPIDocumentationTool."""
    financial_data: Dict[str, Any] = Field(
        ...,
        description="Structured financial data containing metrics, analysis results, and data schema"
    )
    api_name: str = Field(
        default="Financial Analysis API",
        description="Name of the API to generate documentation for"
    )
    api_version: str = Field(
        default="1.0.0",
        description="Version of the API"
    )
    base_url: str = Field(
        default="https://api.financial-analysis.com/v1",
        description="Base URL for the API"
    )

class RestAPIDocumentationTool(BaseTool):
    """Tool for generating comprehensive REST API documentation for financial analysis data."""

    name: str = "rest_api_documentation_tool"
    description: str = (
        "Generates comprehensive REST API documentation for financial analysis data. "
        "Creates OpenAPI 3.0 specification, endpoint examples, code samples, "
        "authentication documentation, and error handling guides."
    )
    args_schema: Type[BaseModel] = RestAPIDocumentationToolInput

    def _run(self, financial_data: Dict[str, Any], api_name: str = "Financial Analysis API", 
             api_version: str = "1.0.0", base_url: str = "https://api.financial-analysis.com/v1") -> str:
        try:
            # Generate OpenAPI 3.0 specification
            openapi_spec = self._generate_openapi_spec(financial_data, api_name, api_version, base_url)
            
            # Generate endpoint examples
            endpoint_examples = self._generate_endpoint_examples(financial_data)
            
            # Generate code samples
            code_samples = self._generate_code_samples(base_url)
            
            # Generate authentication documentation
            auth_docs = self._generate_auth_documentation()
            
            # Generate error response documentation
            error_responses = self._generate_error_responses()
            
            result = {
                "openapi_specification": openapi_spec,
                "endpoint_examples": endpoint_examples,
                "code_samples": code_samples,
                "authentication_docs": auth_docs,
                "error_responses": error_responses
            }
            
            return json.dumps(result, indent=2)
            
        except Exception as e:
            return f"Error generating API documentation: {str(e)}"

    def _generate_openapi_spec(self, financial_data: Dict[str, Any], api_name: str, 
                              api_version: str, base_url: str) -> Dict[str, Any]:
        """Generate OpenAPI 3.0 specification for financial data."""
        
        # Extract data types from financial data for schema generation
        data_fields = list(financial_data.keys()) if financial_data else []
        
        openapi_spec = {
            "openapi": "3.0.3",
            "info": {
                "title": api_name,
                "description": "Comprehensive financial analysis API providing access to financial metrics, calculations, and insights",
                "version": api_version,
                "contact": {
                    "name": "API Support",
                    "email": "support@financial-analysis.com"
                }
            },
            "servers": [
                {
                    "url": base_url,
                    "description": "Production server"
                }
            ],
            "security": [
                {"bearerAuth": []}
            ],
            "components": {
                "securitySchemes": {
                    "bearerAuth": {
                        "type": "http",
                        "scheme": "bearer",
                        "bearerFormat": "JWT"
                    }
                },
                "schemas": {
                    "FinancialMetrics": {
                        "type": "object",
                        "properties": {
                            field: {"type": "number", "description": f"Financial metric: {field}"}
                            for field in data_fields[:10]  # Limit to first 10 fields
                        }
                    },
                    "AnalysisRequest": {
                        "type": "object",
                        "required": ["data", "analysis_type"],
                        "properties": {
                            "data": {
                                "type": "object",
                                "description": "Financial data to analyze"
                            },
                            "analysis_type": {
                                "type": "string",
                                "enum": ["ratio", "trend", "performance", "risk"],
                                "description": "Type of analysis to perform"
                            },
                            "period": {
                                "type": "string",
                                "description": "Analysis period (e.g., quarterly, yearly)"
                            }
                        }
                    },
                    "AnalysisResponse": {
                        "type": "object",
                        "properties": {
                            "analysis_id": {"type": "string"},
                            "results": {"type": "object"},
                            "timestamp": {"type": "string", "format": "date-time"},
                            "status": {"type": "string"}
                        }
                    }
                }
            },
            "paths": {
                "/analyze": {
                    "post": {
                        "summary": "Perform Financial Analysis",
                        "description": "Execute comprehensive financial analysis on provided data",
                        "requestBody": {
                            "required": True,
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/AnalysisRequest"}
                                }
                            }
                        },
                        "responses": {
                            "200": {
                                "description": "Analysis completed successfully",
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/AnalysisResponse"}
                                    }
                                }
                            },
                            "400": {"description": "Invalid request data"},
                            "401": {"description": "Unauthorized"},
                            "500": {"description": "Internal server error"}
                        }
                    }
                },
                "/metrics": {
                    "get": {
                        "summary": "Get Financial Metrics",
                        "description": "Retrieve available financial metrics",
                        "parameters": [
                            {
                                "name": "category",
                                "in": "query",
                                "schema": {"type": "string"},
                                "description": "Filter by metric category"
                            }
                        ],
                        "responses": {
                            "200": {
                                "description": "Metrics retrieved successfully",
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/FinancialMetrics"}
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        return openapi_spec

    def _generate_endpoint_examples(self, financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate sample API request/response examples."""
        
        sample_data = {
            "revenue": 1000000,
            "expenses": 750000,
            "assets": 2500000,
            "liabilities": 1200000
        } if not financial_data else dict(list(financial_data.items())[:4])
        
        return {
            "POST /analyze": {
                "request": {
                    "data": sample_data,
                    "analysis_type": "ratio",
                    "period": "quarterly"
                },
                "response": {
                    "analysis_id": "analysis_12345",
                    "results": {
                        "profit_margin": 0.25,
                        "return_on_assets": 0.10,
                        "debt_to_equity": 0.48,
                        "current_ratio": 2.08
                    },
                    "timestamp": "2024-01-15T10:30:00Z",
                    "status": "completed"
                }
            },
            "GET /metrics": {
                "request": {
                    "query_params": {
                        "category": "profitability"
                    }
                },
                "response": {
                    "metrics": {
                        "gross_profit_margin": 0.35,
                        "net_profit_margin": 0.25,
                        "operating_margin": 0.28,
                        "ebitda_margin": 0.32
                    },
                    "category": "profitability",
                    "last_updated": "2024-01-15T10:30:00Z"
                }
            }
        }

    def _generate_code_samples(self, base_url: str) -> Dict[str, str]:
        """Generate code examples for different programming languages."""
        
        return {
            "python": f'''import requests
import json

# Configuration
BASE_URL = "{base_url}"
API_TOKEN = "your_api_token_here"

headers = {{
    "Authorization": f"Bearer {{API_TOKEN}}",
    "Content-Type": "application/json"
}}

# Perform financial analysis
analysis_data = {{
    "data": {{
        "revenue": 1000000,
        "expenses": 750000,
        "assets": 2500000,
        "liabilities": 1200000
    }},
    "analysis_type": "ratio",
    "period": "quarterly"
}}

response = requests.post(f"{{BASE_URL}}/analyze", json=analysis_data, headers=headers)
result = response.json()
print(json.dumps(result, indent=2))''',

            "javascript": f'''const axios = require('axios');

const BASE_URL = '{base_url}';
const API_TOKEN = 'your_api_token_here';

const headers = {{
    'Authorization': `Bearer ${{API_TOKEN}}`,
    'Content-Type': 'application/json'
}};

// Perform financial analysis
const analysisData = {{
    data: {{
        revenue: 1000000,
        expenses: 750000,
        assets: 2500000,
        liabilities: 1200000
    }},
    analysis_type: 'ratio',
    period: 'quarterly'
}};

axios.post(`${{BASE_URL}}/analyze`, analysisData, {{ headers }})
    .then(response => {{
        console.log(JSON.stringify(response.data, null, 2));
    }})
    .catch(error => {{
        console.error('Error:', error.response?.data || error.message);
    }});''',

            "curl": f'''# Perform financial analysis
curl -X POST "{base_url}/analyze" \\
  -H "Authorization: Bearer your_api_token_here" \\
  -H "Content-Type: application/json" \\
  -d '{{
    "data": {{
      "revenue": 1000000,
      "expenses": 750000,
      "assets": 2500000,
      "liabilities": 1200000
    }},
    "analysis_type": "ratio",
    "period": "quarterly"
  }}'

# Get financial metrics
curl -X GET "{base_url}/metrics?category=profitability" \\
  -H "Authorization: Bearer your_api_token_here"'''
        }

    def _generate_auth_documentation(self) -> Dict[str, Any]:
        """Generate API authentication documentation."""
        
        return {
            "authentication_methods": {
                "bearer_token": {
                    "type": "JWT Bearer Token",
                    "description": "Include your API token in the Authorization header",
                    "header_format": "Authorization: Bearer <your_token>",
                    "token_expiration": "24 hours",
                    "refresh_endpoint": "/auth/refresh"
                }
            },
            "obtaining_tokens": {
                "registration": {
                    "endpoint": "/auth/register",
                    "method": "POST",
                    "required_fields": ["email", "password", "organization"]
                },
                "login": {
                    "endpoint": "/auth/login",
                    "method": "POST",
                    "required_fields": ["email", "password"]
                }
            },
            "security_considerations": [
                "Store tokens securely in environment variables",
                "Never expose tokens in client-side code",
                "Implement token refresh logic for long-running applications",
                "Use HTTPS for all API communications"
            ]
        }

    def _generate_error_responses(self) -> Dict[str, Any]:
        """Generate comprehensive error handling documentation."""
        
        return {
            "http_status_codes": {
                "400": {
                    "description": "Bad Request - Invalid input data",
                    "example": {
                        "error": "validation_error",
                        "message": "Required field 'analysis_type' is missing",
                        "details": {
                            "field": "analysis_type",
                            "code": "required_field_missing"
                        }
                    }
                },
                "401": {
                    "description": "Unauthorized - Invalid or missing token",
                    "example": {
                        "error": "authentication_failed",
                        "message": "Invalid or expired token",
                        "details": {
                            "code": "invalid_token"
                        }
                    }
                },
                "403": {
                    "description": "Forbidden - Insufficient permissions",
                    "example": {
                        "error": "insufficient_permissions",
                        "message": "Your plan does not include access to this endpoint"
                    }
                },
                "429": {
                    "description": "Too Many Requests - Rate limit exceeded",
                    "example": {
                        "error": "rate_limit_exceeded",
                        "message": "Rate limit of 100 requests per minute exceeded",
                        "details": {
                            "reset_time": "2024-01-15T10:31:00Z",
                            "limit": 100,
                            "remaining": 0
                        }
                    }
                },
                "500": {
                    "description": "Internal Server Error",
                    "example": {
                        "error": "internal_server_error",
                        "message": "An unexpected error occurred",
                        "details": {
                            "error_id": "err_12345",
                            "timestamp": "2024-01-15T10:30:00Z"
                        }
                    }
                }
            },
            "error_handling_best_practices": [
                "Always check HTTP status codes before processing responses",
                "Implement exponential backoff for rate limit errors (429)",
                "Log error details for debugging purposes",
                "Provide user-friendly error messages in your application",
                "Handle network timeouts and connection errors gracefully"
            ],
            "common_error_scenarios": {
                "invalid_data_format": {
                    "cause": "Sending data in incorrect format or structure",
                    "solution": "Validate input data against the API schema before sending"
                },
                "missing_required_fields": {
                    "cause": "Required fields not included in the request",
                    "solution": "Check API documentation for required fields"
                },
                "token_expiration": {
                    "cause": "API token has expired",
                    "solution": "Implement automatic token refresh or re-authentication"
                }
            }
        }