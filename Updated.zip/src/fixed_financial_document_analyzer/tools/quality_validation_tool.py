from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Dict, Any, List, Optional
import json
import math

class QualityValidationInput(BaseModel):
    """Input schema for Quality Validation Tool."""
    financial_data: Dict[str, Any] = Field(
        ..., 
        description="Dictionary containing financial data to validate (revenues, expenses, ratios, etc.)"
    )
    benchmarks: Optional[Dict[str, Any]] = Field(
        default={}, 
        description="Dictionary containing benchmark data for cross-reference validation"
    )
    industry_standards: Optional[Dict[str, Any]] = Field(
        default={}, 
        description="Dictionary containing industry standards for ESG and compliance validation"
    )
    regulatory_requirements: Optional[List[str]] = Field(
        default=[], 
        description="List of regulatory requirements to validate against"
    )

class QualityValidationTool(BaseTool):
    """Tool for comprehensive financial data quality validation and reporting."""

    name: str = "QualityValidationTool"
    description: str = (
        "Validates financial data accuracy, consistency, completeness, and compliance. "
        "Performs cross-reference checks against benchmarks, validates financial ratios, "
        "ESG scores, and generates comprehensive quality reports with improvement recommendations."
    )
    args_schema: Type[BaseModel] = QualityValidationInput

    def _run(self, financial_data: Dict[str, Any], benchmarks: Optional[Dict[str, Any]] = None, 
             industry_standards: Optional[Dict[str, Any]] = None, 
             regulatory_requirements: Optional[List[str]] = None) -> str:
        try:
            # Initialize default values
            benchmarks = benchmarks or {}
            industry_standards = industry_standards or {}
            regulatory_requirements = regulatory_requirements or []
            
            # Initialize validation results
            validation_results = {
                "validation_score": 0,
                "accuracy_checks": {},
                "completeness_analysis": {},
                "consistency_report": {},
                "compliance_status": {},
                "quality_grade": "F",
                "improvement_recommendations": []
            }
            
            # 1. Accuracy Checks
            accuracy_score = self._perform_accuracy_checks(financial_data, validation_results)
            
            # 2. Completeness Analysis
            completeness_score = self._perform_completeness_analysis(financial_data, validation_results)
            
            # 3. Consistency Report (Cross-reference checks)
            consistency_score = self._perform_consistency_checks(financial_data, benchmarks, validation_results)
            
            # 4. Financial Ratios Validation
            ratios_score = self._validate_financial_ratios(financial_data, validation_results)
            
            # 5. ESG Scores Validation
            esg_score = self._validate_esg_scores(financial_data, industry_standards, validation_results)
            
            # 6. Compliance Validation
            compliance_score = self._validate_compliance(financial_data, regulatory_requirements, validation_results)
            
            # Calculate overall validation score
            scores = [accuracy_score, completeness_score, consistency_score, ratios_score, esg_score, compliance_score]
            validation_results["validation_score"] = round(sum(scores) / len(scores), 2)
            
            # Assign quality grade
            validation_results["quality_grade"] = self._calculate_quality_grade(validation_results["validation_score"])
            
            # Generate improvement recommendations
            validation_results["improvement_recommendations"] = self._generate_recommendations(validation_results)
            
            return json.dumps(validation_results, indent=2)
            
        except Exception as e:
            return json.dumps({
                "error": f"Validation failed: {str(e)}",
                "validation_score": 0,
                "quality_grade": "F",
                "accuracy_checks": {},
                "completeness_analysis": {},
                "consistency_report": {},
                "compliance_status": {},
                "improvement_recommendations": ["Fix data format and structure issues"]
            }, indent=2)
    
    def _perform_accuracy_checks(self, financial_data: Dict[str, Any], results: Dict[str, Any]) -> float:
        """Perform accuracy validation checks."""
        accuracy_checks = {}
        total_score = 0
        check_count = 0
        
        # Check for negative values where they shouldn't exist
        if "revenue" in financial_data:
            revenue_valid = financial_data["revenue"] >= 0
            accuracy_checks["revenue_non_negative"] = {
                "status": "PASS" if revenue_valid else "FAIL",
                "message": "Revenue should be non-negative" if not revenue_valid else "Revenue value is valid"
            }
            total_score += 100 if revenue_valid else 0
            check_count += 1
        
        # Check for reasonable ranges in percentages
        for key in ["profit_margin", "debt_ratio", "roe", "roa"]:
            if key in financial_data:
                value = financial_data[key]
                is_reasonable = -100 <= value <= 500  # Allow for some extreme cases
                accuracy_checks[f"{key}_reasonable_range"] = {
                    "status": "PASS" if is_reasonable else "FAIL",
                    "message": f"{key} should be within reasonable percentage range (-100% to 500%)"
                }
                total_score += 100 if is_reasonable else 0
                check_count += 1
        
        # Check mathematical relationships
        if all(k in financial_data for k in ["total_assets", "total_liabilities", "equity"]):
            balance_check = abs(financial_data["total_assets"] - (financial_data["total_liabilities"] + financial_data["equity"])) < 0.01
            accuracy_checks["balance_sheet_equation"] = {
                "status": "PASS" if balance_check else "FAIL",
                "message": "Assets = Liabilities + Equity" if balance_check else "Balance sheet equation doesn't balance"
            }
            total_score += 100 if balance_check else 0
            check_count += 1
        
        results["accuracy_checks"] = accuracy_checks
        return total_score / max(check_count, 1)
    
    def _perform_completeness_analysis(self, financial_data: Dict[str, Any], results: Dict[str, Any]) -> float:
        """Analyze data completeness."""
        critical_fields = [
            "revenue", "total_assets", "total_liabilities", "equity", 
            "net_income", "cash_flow", "debt_ratio", "current_ratio"
        ]
        
        missing_fields = []
        present_fields = []
        
        for field in critical_fields:
            if field in financial_data and financial_data[field] is not None:
                present_fields.append(field)
            else:
                missing_fields.append(field)
        
        completeness_percentage = (len(present_fields) / len(critical_fields)) * 100
        
        results["completeness_analysis"] = {
            "completeness_percentage": round(completeness_percentage, 2),
            "missing_critical_fields": missing_fields,
            "present_fields": present_fields,
            "total_critical_fields": len(critical_fields)
        }
        
        return completeness_percentage
    
    def _perform_consistency_checks(self, financial_data: Dict[str, Any], benchmarks: Dict[str, Any], results: Dict[str, Any]) -> float:
        """Perform cross-reference consistency checks."""
        consistency_checks = {}
        total_score = 0
        check_count = 0
        
        # Industry benchmark comparisons
        if benchmarks:
            for metric in ["profit_margin", "debt_ratio", "current_ratio", "roe"]:
                if metric in financial_data and metric in benchmarks:
                    company_value = financial_data[metric]
                    benchmark_value = benchmarks[metric]
                    
                    # Calculate deviation percentage
                    deviation = abs((company_value - benchmark_value) / benchmark_value) * 100 if benchmark_value != 0 else 0
                    
                    # Consider within 50% deviation as reasonable
                    is_consistent = deviation <= 50
                    
                    consistency_checks[f"{metric}_vs_benchmark"] = {
                        "company_value": company_value,
                        "benchmark_value": benchmark_value,
                        "deviation_percent": round(deviation, 2),
                        "status": "CONSISTENT" if is_consistent else "INCONSISTENT"
                    }
                    
                    total_score += 100 if is_consistent else max(0, 100 - deviation)
                    check_count += 1
        
        # Internal consistency checks
        if "current_assets" in financial_data and "current_liabilities" in financial_data:
            calculated_current_ratio = financial_data["current_assets"] / financial_data["current_liabilities"] if financial_data["current_liabilities"] != 0 else 0
            reported_current_ratio = financial_data.get("current_ratio", calculated_current_ratio)
            
            ratio_consistent = abs(calculated_current_ratio - reported_current_ratio) < 0.1
            consistency_checks["current_ratio_calculation"] = {
                "calculated": round(calculated_current_ratio, 2),
                "reported": round(reported_current_ratio, 2),
                "status": "CONSISTENT" if ratio_consistent else "INCONSISTENT"
            }
            
            total_score += 100 if ratio_consistent else 0
            check_count += 1
        
        results["consistency_report"] = consistency_checks
        return total_score / max(check_count, 1)
    
    def _validate_financial_ratios(self, financial_data: Dict[str, Any], results: Dict[str, Any]) -> float:
        """Validate financial ratio calculations."""
        ratio_validations = {}
        total_score = 0
        validation_count = 0
        
        # ROE validation: Net Income / Shareholders' Equity
        if all(k in financial_data for k in ["net_income", "equity", "roe"]):
            calculated_roe = (financial_data["net_income"] / financial_data["equity"]) * 100 if financial_data["equity"] != 0 else 0
            reported_roe = financial_data["roe"]
            
            roe_valid = abs(calculated_roe - reported_roe) < 1.0  # Allow 1% tolerance
            ratio_validations["roe_calculation"] = {
                "calculated": round(calculated_roe, 2),
                "reported": round(reported_roe, 2),
                "status": "VALID" if roe_valid else "INVALID"
            }
            
            total_score += 100 if roe_valid else 0
            validation_count += 1
        
        # Debt-to-Equity ratio validation
        if all(k in financial_data for k in ["total_liabilities", "equity"]):
            debt_to_equity = financial_data["total_liabilities"] / financial_data["equity"] if financial_data["equity"] != 0 else float('inf')
            
            # Check if ratio is reasonable (not extremely high)
            reasonable_debt_ratio = debt_to_equity < 10  # Arbitrary reasonable threshold
            ratio_validations["debt_to_equity_reasonableness"] = {
                "ratio": round(debt_to_equity, 2) if debt_to_equity != float('inf') else "Infinite",
                "status": "REASONABLE" if reasonable_debt_ratio else "CONCERNING"
            }
            
            total_score += 100 if reasonable_debt_ratio else 30
            validation_count += 1
        
        results["accuracy_checks"]["ratio_validations"] = ratio_validations
        return total_score / max(validation_count, 1)
    
    def _validate_esg_scores(self, financial_data: Dict[str, Any], industry_standards: Dict[str, Any], results: Dict[str, Any]) -> float:
        """Validate ESG scores against industry standards."""
        esg_validations = {}
        total_score = 0
        validation_count = 0
        
        esg_metrics = ["environmental_score", "social_score", "governance_score", "overall_esg_score"]
        
        for metric in esg_metrics:
            if metric in financial_data:
                score = financial_data[metric]
                
                # Basic range validation (assuming 0-100 scale)
                valid_range = 0 <= score <= 100
                esg_validations[f"{metric}_range"] = {
                    "score": score,
                    "status": "VALID" if valid_range else "INVALID",
                    "message": "Score within valid range (0-100)" if valid_range else "Score outside valid range"
                }
                
                total_score += 100 if valid_range else 0
                validation_count += 1
                
                # Industry standard comparison
                if metric in industry_standards:
                    industry_avg = industry_standards[metric]
                    deviation = abs(score - industry_avg)
                    
                    # Consider within 20 points as acceptable
                    acceptable_deviation = deviation <= 20
                    esg_validations[f"{metric}_industry_comparison"] = {
                        "company_score": score,
                        "industry_average": industry_avg,
                        "deviation": deviation,
                        "status": "ACCEPTABLE" if acceptable_deviation else "NEEDS_ATTENTION"
                    }
                    
                    total_score += 100 if acceptable_deviation else max(0, 100 - deviation * 2)
                    validation_count += 1
        
        results["accuracy_checks"]["esg_validations"] = esg_validations
        return total_score / max(validation_count, 1)
    
    def _validate_compliance(self, financial_data: Dict[str, Any], regulatory_requirements: List[str], results: Dict[str, Any]) -> float:
        """Validate compliance against regulatory requirements."""
        compliance_checks = {}
        total_score = 0
        check_count = 0
        
        # Common regulatory compliance checks
        for requirement in regulatory_requirements:
            if requirement.lower() == "sarbanes_oxley":
                # Check for required financial disclosures
                required_fields = ["revenue", "net_income", "total_assets", "cash_flow"]
                missing_sox_fields = [field for field in required_fields if field not in financial_data]
                
                sox_compliant = len(missing_sox_fields) == 0
                compliance_checks["sarbanes_oxley"] = {
                    "status": "COMPLIANT" if sox_compliant else "NON_COMPLIANT",
                    "missing_fields": missing_sox_fields,
                    "message": "All required SOX fields present" if sox_compliant else f"Missing SOX required fields: {missing_sox_fields}"
                }
                
                total_score += 100 if sox_compliant else 50
                check_count += 1
                
            elif requirement.lower() == "basel_iii" and "bank" in str(financial_data).lower():
                # Basic Basel III capital adequacy check
                if "tier1_capital_ratio" in financial_data:
                    tier1_ratio = financial_data["tier1_capital_ratio"]
                    basel_compliant = tier1_ratio >= 6.0  # Minimum requirement
                    
                    compliance_checks["basel_iii_tier1"] = {
                        "tier1_ratio": tier1_ratio,
                        "minimum_required": 6.0,
                        "status": "COMPLIANT" if basel_compliant else "NON_COMPLIANT"
                    }
                    
                    total_score += 100 if basel_compliant else 0
                    check_count += 1
        
        # Generic compliance score if no specific requirements
        if not regulatory_requirements:
            # Check for basic transparency indicators
            transparency_score = 0
            if "audited" in financial_data and financial_data["audited"]:
                transparency_score += 50
            if "quarterly_reports" in financial_data and financial_data["quarterly_reports"]:
                transparency_score += 50
                
            compliance_checks["general_transparency"] = {
                "audited": financial_data.get("audited", False),
                "quarterly_reports": financial_data.get("quarterly_reports", False),
                "transparency_score": transparency_score
            }
            
            total_score = transparency_score
            check_count = 1
        
        results["compliance_status"] = compliance_checks
        return total_score / max(check_count, 1)
    
    def _calculate_quality_grade(self, score: float) -> str:
        """Calculate letter grade based on overall score."""
        if score >= 95:
            return "A+"
        elif score >= 90:
            return "A"
        elif score >= 85:
            return "A-"
        elif score >= 80:
            return "B+"
        elif score >= 75:
            return "B"
        elif score >= 70:
            return "B-"
        elif score >= 65:
            return "C+"
        elif score >= 60:
            return "C"
        elif score >= 55:
            return "C-"
        elif score >= 50:
            return "D"
        else:
            return "F"
    
    def _generate_recommendations(self, results: Dict[str, Any]) -> List[str]:
        """Generate improvement recommendations based on validation results."""
        recommendations = []
        
        # Accuracy recommendations
        if "accuracy_checks" in results:
            for check_name, check_result in results["accuracy_checks"].items():
                if isinstance(check_result, dict) and check_result.get("status") in ["FAIL", "INVALID"]:
                    recommendations.append(f"Address {check_name}: {check_result.get('message', 'Review and correct this metric')}")
        
        # Completeness recommendations
        if "completeness_analysis" in results:
            missing_fields = results["completeness_analysis"].get("missing_critical_fields", [])
            if missing_fields:
                recommendations.append(f"Provide missing critical financial data: {', '.join(missing_fields)}")
        
        # Consistency recommendations
        if "consistency_report" in results:
            for check_name, check_result in results["consistency_report"].items():
                if isinstance(check_result, dict) and check_result.get("status") == "INCONSISTENT":
                    recommendations.append(f"Review data consistency for {check_name}")
        
        # Compliance recommendations
        if "compliance_status" in results:
            for check_name, check_result in results["compliance_status"].items():
                if isinstance(check_result, dict) and check_result.get("status") == "NON_COMPLIANT":
                    recommendations.append(f"Address compliance issue: {check_name}")
        
        # Overall score recommendations
        score = results.get("validation_score", 0)
        if score < 70:
            recommendations.append("Overall data quality is below acceptable standards - conduct comprehensive review")
        elif score < 85:
            recommendations.append("Data quality is acceptable but has room for improvement")
        
        # Default recommendation if no specific issues found
        if not recommendations:
            recommendations.append("Data quality is good - maintain current standards and regular validation")
        
        return recommendations[:10]  # Limit to top 10 recommendations