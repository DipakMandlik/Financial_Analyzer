from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Dict, Any, List
import json
import math
from statistics import mean, median, stdev

class PerformanceMonitoringInput(BaseModel):
    """Input schema for Performance Monitoring Tool."""
    analysis_results: Dict[str, Any] = Field(
        ...,
        description="Dictionary containing analysis results and outcomes"
    )
    processing_metadata: Dict[str, Any] = Field(
        ...,
        description="Dictionary containing processing times, resource usage, and execution metadata"
    )

class PerformanceMonitoringTool(BaseTool):
    """Tool for tracking and analyzing automation performance metrics with comprehensive monitoring capabilities."""

    name: str = "performance_monitoring_tool"
    description: str = (
        "Analyzes automation performance metrics including processing times, resource utilization, "
        "data quality scores, success rates, and generates comprehensive performance reports with "
        "bottleneck identification and scalability recommendations."
    )
    args_schema: Type[BaseModel] = PerformanceMonitoringInput

    def _run(self, analysis_results: Dict[str, Any], processing_metadata: Dict[str, Any]) -> str:
        try:
            # Initialize performance analysis
            performance_data = self._analyze_performance_metrics(processing_metadata)
            quality_data = self._analyze_quality_metrics(analysis_results, processing_metadata)
            system_health = self._analyze_system_health(processing_metadata)
            scalability_analysis = self._analyze_scalability(processing_metadata, performance_data)
            monitoring_dashboard = self._generate_dashboard_metrics(performance_data, quality_data, system_health)
            recommendations = self._generate_recommendations(performance_data, quality_data, system_health, scalability_analysis)

            # Compile comprehensive performance report
            performance_report = {
                'performance_metrics': performance_data,
                'quality_metrics': quality_data,
                'system_health': system_health,
                'scalability_analysis': scalability_analysis,
                'monitoring_dashboard': monitoring_dashboard,
                'recommendations': recommendations
            }

            return json.dumps(performance_report, indent=2)

        except Exception as e:
            return f"Error analyzing performance metrics: {str(e)}"

    def _analyze_performance_metrics(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze processing times, success rates, and throughput metrics."""
        try:
            # Extract timing data
            processing_times = metadata.get('processing_times', {})
            execution_data = metadata.get('execution_data', {})
            
            # Calculate phase processing times
            phase_times = {}
            total_time = 0
            
            for phase, time_data in processing_times.items():
                if isinstance(time_data, (int, float)):
                    phase_times[phase] = {
                        'duration': time_data,
                        'percentage': 0  # Will calculate after total
                    }
                    total_time += time_data
                elif isinstance(time_data, list) and time_data:
                    avg_time = mean(time_data)
                    phase_times[phase] = {
                        'duration': avg_time,
                        'min_time': min(time_data),
                        'max_time': max(time_data),
                        'std_dev': stdev(time_data) if len(time_data) > 1 else 0,
                        'percentage': 0
                    }
                    total_time += avg_time

            # Calculate percentages
            for phase in phase_times:
                if total_time > 0:
                    phase_times[phase]['percentage'] = (phase_times[phase]['duration'] / total_time) * 100

            # Calculate success rates
            total_tasks = execution_data.get('total_tasks', 0)
            successful_tasks = execution_data.get('successful_tasks', 0)
            failed_tasks = execution_data.get('failed_tasks', 0)
            
            success_rate = (successful_tasks / total_tasks * 100) if total_tasks > 0 else 0
            error_rate = (failed_tasks / total_tasks * 100) if total_tasks > 0 else 0

            # Calculate throughput
            execution_time = execution_data.get('total_execution_time', total_time)
            throughput = (total_tasks / execution_time * 3600) if execution_time > 0 else 0  # tasks per hour

            return {
                'phase_processing_times': phase_times,
                'total_processing_time': total_time,
                'success_rate_percentage': round(success_rate, 2),
                'error_rate_percentage': round(error_rate, 2),
                'throughput_per_hour': round(throughput, 2),
                'total_tasks_processed': total_tasks,
                'successful_tasks': successful_tasks,
                'failed_tasks': failed_tasks,
                'average_task_time': round(total_time / total_tasks, 3) if total_tasks > 0 else 0
            }

        except Exception as e:
            return {'error': f"Failed to analyze performance metrics: {str(e)}"}

    def _analyze_quality_metrics(self, results: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze data quality scores and validation results."""
        try:
            quality_scores = results.get('quality_scores', {})
            validation_results = results.get('validation_results', {})
            
            # Calculate overall quality metrics
            accuracy_scores = []
            completeness_scores = []
            consistency_scores = []

            # Extract quality scores
            for metric, value in quality_scores.items():
                if 'accuracy' in metric.lower() and isinstance(value, (int, float)):
                    accuracy_scores.append(value)
                elif 'completeness' in metric.lower() and isinstance(value, (int, float)):
                    completeness_scores.append(value)
                elif 'consistency' in metric.lower() and isinstance(value, (int, float)):
                    consistency_scores.append(value)

            # Calculate averages
            avg_accuracy = mean(accuracy_scores) if accuracy_scores else 0
            avg_completeness = mean(completeness_scores) if completeness_scores else 0
            avg_consistency = mean(consistency_scores) if consistency_scores else 0

            # Validation analysis
            validation_passed = validation_results.get('passed_validations', 0)
            validation_failed = validation_results.get('failed_validations', 0)
            total_validations = validation_passed + validation_failed
            validation_pass_rate = (validation_passed / total_validations * 100) if total_validations > 0 else 0

            # Data quality assessment
            overall_quality = (avg_accuracy + avg_completeness + avg_consistency + validation_pass_rate) / 4

            return {
                'accuracy_score': round(avg_accuracy, 2),
                'completeness_score': round(avg_completeness, 2),
                'consistency_score': round(avg_consistency, 2),
                'validation_pass_rate': round(validation_pass_rate, 2),
                'overall_quality_score': round(overall_quality, 2),
                'total_validations': total_validations,
                'passed_validations': validation_passed,
                'failed_validations': validation_failed,
                'quality_grade': self._get_quality_grade(overall_quality)
            }

        except Exception as e:
            return {'error': f"Failed to analyze quality metrics: {str(e)}"}

    def _analyze_system_health(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze system resource utilization and identify bottlenecks."""
        try:
            resource_data = metadata.get('resource_utilization', {})
            performance_data = metadata.get('performance_indicators', {})
            
            # Estimate resource utilization
            cpu_usage = resource_data.get('cpu_usage_percent', 0)
            memory_usage = resource_data.get('memory_usage_percent', 0)
            io_operations = resource_data.get('io_operations', 0)
            
            # Identify bottlenecks
            bottlenecks = []
            if cpu_usage > 80:
                bottlenecks.append({'type': 'CPU', 'severity': 'High', 'usage': cpu_usage})
            elif cpu_usage > 60:
                bottlenecks.append({'type': 'CPU', 'severity': 'Medium', 'usage': cpu_usage})
                
            if memory_usage > 85:
                bottlenecks.append({'type': 'Memory', 'severity': 'High', 'usage': memory_usage})
            elif memory_usage > 70:
                bottlenecks.append({'type': 'Memory', 'severity': 'Medium', 'usage': memory_usage})

            # System health score
            health_score = 100
            health_score -= max(0, cpu_usage - 50)
            health_score -= max(0, memory_usage - 50)
            health_score = max(0, health_score)

            return {
                'cpu_utilization_percent': cpu_usage,
                'memory_utilization_percent': memory_usage,
                'io_operations_count': io_operations,
                'identified_bottlenecks': bottlenecks,
                'system_health_score': round(health_score, 2),
                'health_status': self._get_health_status(health_score),
                'resource_efficiency': round((200 - cpu_usage - memory_usage) / 2, 2)
            }

        except Exception as e:
            return {'error': f"Failed to analyze system health: {str(e)}"}

    def _analyze_scalability(self, metadata: Dict[str, Any], performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze scalability patterns and provide load capacity recommendations."""
        try:
            current_throughput = performance_data.get('throughput_per_hour', 0)
            avg_task_time = performance_data.get('average_task_time', 0)
            success_rate = performance_data.get('success_rate_percentage', 0)
            
            # Estimate scaling capacity
            max_theoretical_capacity = (3600 / avg_task_time) if avg_task_time > 0 else 0
            current_efficiency = (current_throughput / max_theoretical_capacity * 100) if max_theoretical_capacity > 0 else 0
            
            # Scalability recommendations
            scaling_factor = 1.0
            if success_rate > 95 and current_efficiency < 70:
                scaling_factor = 1.5  # Can handle 50% more load
            elif success_rate > 90 and current_efficiency < 80:
                scaling_factor = 1.3  # Can handle 30% more load
            elif success_rate < 85:
                scaling_factor = 0.8  # Should reduce load by 20%

            recommended_capacity = current_throughput * scaling_factor

            return {
                'current_throughput': current_throughput,
                'max_theoretical_capacity': round(max_theoretical_capacity, 2),
                'current_efficiency_percent': round(current_efficiency, 2),
                'recommended_capacity': round(recommended_capacity, 2),
                'scaling_factor': scaling_factor,
                'scalability_rating': self._get_scalability_rating(current_efficiency, success_rate),
                'load_handling_capacity': 'High' if scaling_factor > 1.3 else 'Medium' if scaling_factor > 1.0 else 'Limited'
            }

        except Exception as e:
            return {'error': f"Failed to analyze scalability: {str(e)}"}

    def _generate_dashboard_metrics(self, performance: Dict, quality: Dict, health: Dict) -> Dict[str, Any]:
        """Generate summary metrics for system monitoring dashboard."""
        try:
            return {
                'overall_system_score': round((
                    performance.get('success_rate_percentage', 0) * 0.3 +
                    quality.get('overall_quality_score', 0) * 0.3 +
                    health.get('system_health_score', 0) * 0.4
                ), 2),
                'key_performance_indicators': {
                    'success_rate': f"{performance.get('success_rate_percentage', 0)}%",
                    'quality_score': f"{quality.get('overall_quality_score', 0)}%",
                    'system_health': f"{health.get('system_health_score', 0)}%",
                    'throughput': f"{performance.get('throughput_per_hour', 0)} tasks/hour"
                },
                'alert_conditions': self._generate_alerts(performance, quality, health),
                'trend_indicators': {
                    'performance_trend': 'Stable',
                    'quality_trend': 'Stable',
                    'health_trend': 'Stable'
                }
            }
        except Exception as e:
            return {'error': f"Failed to generate dashboard metrics: {str(e)}"}

    def _generate_recommendations(self, performance: Dict, quality: Dict, health: Dict, scalability: Dict) -> List[str]:
        """Generate performance improvement recommendations."""
        recommendations = []
        
        try:
            # Performance recommendations
            if performance.get('success_rate_percentage', 0) < 90:
                recommendations.append("Investigate and address error patterns to improve success rate above 90%")
            
            if performance.get('error_rate_percentage', 0) > 10:
                recommendations.append("Implement additional error handling and retry mechanisms")

            # Quality recommendations  
            if quality.get('overall_quality_score', 0) < 80:
                recommendations.append("Enhance data validation processes to improve overall quality score")
                
            if quality.get('validation_pass_rate', 0) < 85:
                recommendations.append("Review and strengthen data validation rules")

            # System health recommendations
            if health.get('system_health_score', 0) < 70:
                recommendations.append("Consider system optimization or resource scaling to improve health score")
                
            for bottleneck in health.get('identified_bottlenecks', []):
                if bottleneck['severity'] == 'High':
                    recommendations.append(f"Address high {bottleneck['type']} utilization ({bottleneck['usage']}%)")

            # Scalability recommendations
            if scalability.get('current_efficiency_percent', 0) < 60:
                recommendations.append("Optimize processing algorithms to improve resource efficiency")
                
            if scalability.get('scaling_factor', 1.0) < 1.0:
                recommendations.append("Consider reducing system load or implementing load balancing")

            if not recommendations:
                recommendations.append("System performance is optimal - continue monitoring for maintenance")

            return recommendations[:10]  # Limit to top 10 recommendations

        except Exception as e:
            return [f"Error generating recommendations: {str(e)}"]

    def _get_quality_grade(self, score: float) -> str:
        """Convert quality score to letter grade."""
        if score >= 90: return 'A'
        elif score >= 80: return 'B' 
        elif score >= 70: return 'C'
        elif score >= 60: return 'D'
        else: return 'F'

    def _get_health_status(self, score: float) -> str:
        """Convert health score to status."""
        if score >= 80: return 'Excellent'
        elif score >= 60: return 'Good'
        elif score >= 40: return 'Fair'
        else: return 'Poor'

    def _get_scalability_rating(self, efficiency: float, success_rate: float) -> str:
        """Determine scalability rating."""
        if efficiency > 80 and success_rate > 95: return 'Excellent'
        elif efficiency > 60 and success_rate > 90: return 'Good'
        elif efficiency > 40 and success_rate > 80: return 'Fair'
        else: return 'Limited'

    def _generate_alerts(self, performance: Dict, quality: Dict, health: Dict) -> List[str]:
        """Generate system alerts based on metrics."""
        alerts = []
        
        if performance.get('success_rate_percentage', 0) < 85:
            alerts.append('CRITICAL: Success rate below 85%')
            
        if quality.get('overall_quality_score', 0) < 70:
            alerts.append('WARNING: Data quality score below 70%')
            
        if health.get('system_health_score', 0) < 60:
            alerts.append('CRITICAL: System health score below 60%')
            
        return alerts