import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	FileReadTool,
	SerperDevTool
)
from fixed_financial_document_analyzer.tools.financial_data_formatter import FinancialDataFormatterTool
from fixed_financial_document_analyzer.tools.quality_validation_tool import QualityValidationTool
from fixed_financial_document_analyzer.tools.performance_monitoring_tool import PerformanceMonitoringTool
from fixed_financial_document_analyzer.tools.rest_api_documentation_tool import RestAPIDocumentationTool

from crewai_tools import CrewaiEnterpriseTools



@CrewBase
class FixedFinancialDocumentAnalyzerCrew:
    """FixedFinancialDocumentAnalyzer crew"""

    
    @agent
    def financial_document_analyst(self) -> Agent:

        
        return Agent(
            config=self.agents_config["financial_document_analyst"],
            
            
            tools=[
				FileReadTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def market_research_analyst(self) -> Agent:

        
        return Agent(
            config=self.agents_config["market_research_analyst"],
            
            
            tools=[
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def investment_risk_assessor(self) -> Agent:

        
        return Agent(
            config=self.agents_config["investment_risk_assessor"],
            
            
            tools=[
				SerperDevTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def financial_report_synthesizer(self) -> Agent:
        enterprise_actions_tool = CrewaiEnterpriseTools(
            actions_list=[
                
                "google_sheets_create_row",
                
            ],
        )

        
        return Agent(
            config=self.agents_config["financial_report_synthesizer"],
            
            
            tools=[
				FileReadTool(),
				FinancialDataFormatterTool(),
				QualityValidationTool(),
				PerformanceMonitoringTool(),
				RestAPIDocumentationTool(),
				*enterprise_actions_tool
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def analyze_financial_document(self) -> Task:
        return Task(
            config=self.tasks_config["analyze_financial_document"],
            markdown=False,
            
        )
    
    @task
    def conduct_market_research(self) -> Task:
        return Task(
            config=self.tasks_config["conduct_market_research"],
            markdown=False,
            
        )
    
    @task
    def assess_investment_risk(self) -> Task:
        return Task(
            config=self.tasks_config["assess_investment_risk"],
            markdown=False,
            
        )
    
    @task
    def generate_comprehensive_financial_report(self) -> Task:
        return Task(
            config=self.tasks_config["generate_comprehensive_financial_report"],
            markdown=False,
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the FixedFinancialDocumentAnalyzer crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )

    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)
